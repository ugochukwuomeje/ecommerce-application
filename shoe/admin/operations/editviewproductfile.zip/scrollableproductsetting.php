<div class='row'>
						<div class='col-md-3'>
							<a href='addscrollableproduct.php' role='button' class='btn btn-primary btn-small'>ADD SCROLLABLE PRODUCT</a>
						</div>
						<div class='col-md-3'>
							<a href='deletescrollableproduct.php' role='button' class='btn btn-warning btn-small'>DELETE SCROLLABLE PRODUCT</a>
						</div>
						<div class='col-md-3'>
							<a href='editscrollableproduct.php' role='button' class='btn btn-success btn-small'>EDIT SCROLLABLE PRODUCT</a>
						</div>
						<div class='col-md-3'>
							<a href='disablescrollableproduct.php' role='button' class='btn btn-default btn-small'>DISABLE SCROLLABLE PRODUCT</a>
						</div>
					</div><br><br>