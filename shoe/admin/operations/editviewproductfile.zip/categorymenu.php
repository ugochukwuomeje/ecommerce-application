<div class='row'>
						<div class='col-md-3'>
							<a href='addcategory.php' role='button' class='btn btn-primary btn-small'>ADD CATEGORY</a>
						</div>
						<div class='col-md-3'>
							<a href='disablecategroy.php' role='button' class='btn btn-warning btn-small'>DISABLE CATEGORY</a>
						</div>
						<div class='col-md-3'>
							<a href='enablecategory.php' role='button' class='btn btn-success btn-small'>ENABLE CATEGORY</a>
						</div>
						<div class='col-md-3'>
							<a href='editcategory.php' role='button' class='btn btn-default btn-small'>EDIT CATEGORY</a>
						</div>
					</div><br><br>