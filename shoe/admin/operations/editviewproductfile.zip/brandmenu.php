<div class='row'>
						<div class='col-md-3'>
							<a href='addbrand.php' role='button' class='btn btn-primary btn-small'>ADD BRAND</a>
						</div>
						<div class='col-md-3'>
							<a href='disablebrand.php' role='button' class='btn btn-warning btn-small'>DISABLE BRAND</a>
						</div>
						<div class='col-md-3'>
							<a href='enablebrand.php' role='button' class='btn btn-success btn-small'>ENABLE BRAND</a>
						</div>
						<div class='col-md-3'>
							<a href='editbrand.php' role='button' class='btn btn-default btn-small'>EDIT BRAND</a>
						</div>
					</div><br><br>