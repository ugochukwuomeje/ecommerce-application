<div class='row'>
						<div class='col-md-3'>
							<a href='add_product.php' role='button' class='btn btn-primary btn-small'>ADD PRODUCT</a>
						</div>
						<div class='col-md-3'>
							<a href='deleteproduct.php' role='button' class='btn btn-warning btn-small'>DELETE PRODUCT</a>
						</div>
						<div class='col-md-3'>
							<a href='editproduct.php' role='button' class='btn btn-success btn-small'>EDIT PRODUCT</a>
						</div>
						<div class='col-md-3'>
							<a href='allproduct.php' role='button' class='btn btn-default btn-small'>ALL PRODUCT</a>
						</div>
					</div><br><br>