<footer class="row-footer jumbotron" style='color:white; background-color:#4682B4; font-size:1.2em; height:500px; margin-top:-1em'>
        <div class="container" >
            <div class="row" style='margin-top:3em'>             
                <div class="col-xs-5 col-xs-offset-1 col-sm-2 col-sm-offset-1" >
                  
                    <ul class="list-unstyled">
                        <li ><a href="dashboard.php" style='color:white'>Home</a></li><br>
                        <li><a href="add_product.php" style='color:white'>Add product</a></li><br>
                        <li><a href="addcategory.php" style='color:white'>Add category</a></li><br>
						 <li><a href="addsubcategory.php" style='color:white'>Add sub category</a></li><br>
                       <li><a href="addbrand.php" style='color:white'>Add brands</a></li><br>
						<li><a href="logout.php" style='color:white'>Logout</a></li>
						
                    </ul>
                </div>
                <div class="col-xs-6 col-sm-5">
                    
		          <i class="fa fa-phone"></i>: +234 706 356 9621<br>
		          
		          <i class="fa fa-envelope"></i>: 
                  <a href="#" style='color:white'>info@exotiscent.com</a>
		           </address>
                </div>
                <div class="col-xs-12 col-sm-4">
                    <div class="nav navbar-nav" style="padding: 40px 10px;">
                        <a class="btn btn-social-icon btn-google-plus" href="http://google.com/+"><i class="fa fa-google-plus"></i></a>
                        <a class="btn btn-social-icon btn-facebook" href="http://www.facebook.com/profile.php?id="><i class="fa fa-facebook"></i></a>
                        <a class="btn btn-social-icon btn-linkedin" href="http://www.linkedin.com/in/"><i class="fa fa-linkedin"></i></a>
                        <a class="btn btn-social-icon btn-twitter" href="http://twitter.com/"><i class="fa fa-twitter"></i></a>
                        <a class="btn btn-social-icon btn-youtube" href="http://youtube.com/"><i class="fa fa-youtube"></i></a>
                        <a class="btn btn-social-icon" href="mailto:"><i class="fa fa-envelope-o"></i></a>
                    </div>
                </div>
               
            </div>
        </div>
		 
    </footer>
	<div class="container-fliud" style=' background-color:black'>
                    <p style="padding:10px;"></p>
                    <p align="center" style='color:white;'>© Copyright 2017 exotiscent.com</p>
					<br>
                </div>